### v3.0
* Update for Magisk 26